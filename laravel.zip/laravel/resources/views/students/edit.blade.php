<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
@extends('students.layout')

@section('content')
@if ($errors->any())
    <div  >
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
 <body>
 <div>
 	<div style="background-image: url('https://lh3.googleusercontent.com/proxy/wfmgl8sGW4cN8qvmSCO20oiPPPw_hiycPzJLV1cZHCvLjlCrtSnJJus2B6dr5ZgGOhfR5-IBoV_VhCxnv65m3pBVRMC0CnD_f8E3pQnAKSxsM07lu1z_qxjQ');" style="background-repeat: no-repeat;">
	<form   action="{{route('students.update',$student->id) }}"  method="POST">
 	 	@csrf
 	 	@method('PUT')
 	 	<label for="exampleFormControlInput1" class="form-label"> নাম </label>
		<input class="form-control" type="text" id="exampleInputEmail1" aria-describedby="emailHelp"  name="student_id" placeholder="Name" value="{{$student->student_id}}"> 
		<br>
 	 	<label for="exampleFormControlInput1" class="form-label"> মোবাইল নাম্বার </label>

		<input class="form-control" type="text" name="name" placeholder="Mobile Number" value="{{$student->name}}">
		<br>
<label for="exampleFormControlInput1" class="form-label">  ঠিকানা </label>
		 <input class="form-control" type="text" name="batch" placeholder="Address" value="{{$student->batch}}">

		<br><br>
		<button class="btn btn-success" type="submit" >Update</button>

		


	</form>

</div>

</body>
</html>