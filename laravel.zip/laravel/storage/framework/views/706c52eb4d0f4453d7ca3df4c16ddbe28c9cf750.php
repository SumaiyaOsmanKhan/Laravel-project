<html>
<head> 
	<title> CSE 323: Web Programming Laravel Project</title>
</head>
<body>
	<div class="container"> 
		<?php echo $__env->yieldContent('content'); ?>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/layout.blade.php ENDPATH**/ ?>